//==============================================================================
// BOOLEAN GROUP TYPE CONSTANTS
//==============================================================================
/** @class */
net.user1.orbiter.filters.BooleanGroupType = new Object();
/** @constant */
net.user1.orbiter.filters.BooleanGroupType.AND = "AND";
/** @constant */
net.user1.orbiter.filters.BooleanGroupType.OR = "OR";