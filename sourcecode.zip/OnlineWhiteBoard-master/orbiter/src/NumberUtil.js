//==============================================================================
// A COLLECTION OF NUMERIC UTILITIES
//==============================================================================
/** @class */
net.user1.utils.integer = new Object();
/** @constant */
net.user1.utils.integer.MAX_VALUE = Math.pow(2,32) - 1;