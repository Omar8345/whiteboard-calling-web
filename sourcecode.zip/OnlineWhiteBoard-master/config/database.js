// config/database.js
module.exports = {

     // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

    'url': 'mongodb://<heroku_sf2x42cj>:<pass123>@ds127300.mlab.com:27300/onlinewhiteboard'
    //'url' : 'mongodb://localhost:27017/onlinewhiteboard'
};
